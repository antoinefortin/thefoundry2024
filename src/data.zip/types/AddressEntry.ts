export interface AddressEntry
{
    id           : string,
    firstName    : string,
    lastName     : string,
    phoneNumber? : string
}